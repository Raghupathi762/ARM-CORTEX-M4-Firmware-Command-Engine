/*
Author      : Firmware Developer
Project Credits:-
Embedded Firmware Development
Platform: STM32F401RBT6
Language: Bare-metal Embedded C
IDE: Keil �Vision
project name : UART-Based Embedded Command-Line Interface
### STM32F401RBT6 | Bare-Metal Embedded C
A register-level firmware project implementing a UART-based
command-line interface for peripheral control, system
monitoring, RTC time/date access, ADC temperature
measurement, and ESP8266 Wi-Fi communication using AT commands.
*/
#include "stm32f401rbt6.h"
#include "main.h"

char ch,j,found;
extern uint8_t RX_DATA[200];
extern uint8_t  i;
extern char flag;
extern void (*SENDER)(void);
int	main()
  {
                              		/*INIT SECTION */
	Uart2_Init();	
	KM_I2C1_Init();
	KM_I2C1_Config();
	Km_wifi_init();
	KM_GPIO_Init(GPIOB_PORT);
	km_adc_init();
	KM_GPIO_Pin_Mode(GPIOB_PORT,13,OUT);//PORTB LED OUTPUT MODE
	KM_GPIO_Write_Pin(GPIOB_PORT,13,1);//PORTB LED OFF 
	uart_string((uint8_t *)"\r\n");
	uart_string((uint8_t *)"========================================\r\n");
	uart_string((uint8_t *)"   UART-Based Command-Line Interface (CLI) \r\n");
	uart_string((uint8_t *)"========================================\r\n");
	uart_string((uint8_t *)GREEN);
  uart_string((uint8_t *)"STM32:-/myproject/uart/cmd/line$ ");
	uart_string((uint8_t *)RESETT);
  while(1)
	{
		if(flag &0x01)//THIS LOGIC FOR BACKSPACE
		{
			ch=RX_DATA[i-1];
			if(ch == '\b' || ch == 0x7F)//checking for backspace and delete button
			{
				if(i > 1)
				{
					i -= 2;
					RX_DATA[i] = '\0';
					
					uart_string((uint8_t*)"\b \b");
					flag &=~(1<<0);
			    }
			}
			else
			{
		    uart_string((uint8_t *)YELLOW);//cmd print on yellow color
			  uart2_tx(ch);
		    uart_string((uint8_t *)RESETT);//color reset
			flag &=~(1<<0);
			}  
		} 
		command_execute((char *)RX_DATA);//executeing cmds
	}
	}