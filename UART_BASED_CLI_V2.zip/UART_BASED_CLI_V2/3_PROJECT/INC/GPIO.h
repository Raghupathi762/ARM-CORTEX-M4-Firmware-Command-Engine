/******************************RAAYANMINI ******************************/
#define RED_LED 13
#define GREEN_LED 14
#define BUZZER 12
#define SW_UP 8
#define SW_DW 9
#define SW_ENT 10
/***********************GPIPO PORTS**********************************/
#define GPIOA_PORT  0
#define GPIOB_PORT  1
#define GPIOC_PORT  2
/***************************GPIO MODES ****************************************/
#define IN  0
#define OUT 1
#define ALT 2
#define ANL 3
/******************************************************************************************************/
#define SET 1
#define RESET 0
/***************************************PULL UP PULL DOWN **********************************************************/
#define PULL_UP 5
#define PULL_DOWN 6
/******************************GPIO DECLARATION **********************************************/
void KM_GPIO_Init(unsigned int port );
void KM_GPIO_Pin_Mode(unsigned int port,unsigned int pin,unsigned int mode );
void KM_GPIO_Write_Pin(unsigned int port,unsigned int pin,unsigned int data);
void KM_GPIO_Toggle(unsigned int port ,unsigned int  pin);
int KM_GPIO_Read_Pin(unsigned int port ,unsigned int  pin);
