#include<stdint.h>
#ifndef WIFI_H
#define WIFI_H
void AT(void);
void AT_RST(void);
void AT_CWMODE(void);
void AT_CWJAP(void);
void AT_MUX(void);
void AT_CIPSTART(void);
void AT_CIPSTATUS(void);
void AT_CIPSEND(void);
void AT_POST(void);
void UART_OUT_Char_red(char data);
void UART_OUT_WRITE_CMD(char str[]);
void	Km_wifi_init(void);
#endif