#ifndef HISTORY_H
#define HISTORY_H
void history_save(void);
void history_show(void);
void history_clear(void);
#endif