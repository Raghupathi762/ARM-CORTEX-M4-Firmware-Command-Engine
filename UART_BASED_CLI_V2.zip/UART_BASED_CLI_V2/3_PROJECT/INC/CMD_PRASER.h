#ifndef COMMAND_H
#define COMMAND_H
void help_cmd(void);
void version_cmd(void);
void clear_cmd(void);
void info_cmd(void);
void time_cmd(void);
void date_cmd(void);
void wrong_cmd(void);
void led_on_cmd(void);
void led_off_cmd(void);
void board_info_cmd(void);
void command_execute(char *RX_DATA);
void adc_info_cmd(void);
void gpio_info_cmd(void);
void interrupt_info_cmd(void);
void adc_temp_cmd(void);
void whoami_cmd(void);
void wifi_info_cmd(void);
void wifi_status_cmd(void);
void reset_cmd(void);
void history_info_cmd(void);
void history_clear_cmd(void);
#endif