#ifndef UART2_H
#define UART2_H
#include<stdint.h>
void Uart2_Init(void);	
void uart_string(uint8_t str[]);
void uart2_tx(uint8_t);
#endif
	