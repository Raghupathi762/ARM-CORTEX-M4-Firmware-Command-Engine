#ifndef MAIN_H
#define MAIN_H
#include "UART.h"
#include "i2c.h"
#include "GPIO.h"
#include "adc.h"
#include "UART.h"
#include "ADC_STM32.h"
#include "memory.h"
#include "CMD_PRASER.h"
#include "WIFI_HEADER.h"
#include "terminal_color.h"
#include "history.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#endif