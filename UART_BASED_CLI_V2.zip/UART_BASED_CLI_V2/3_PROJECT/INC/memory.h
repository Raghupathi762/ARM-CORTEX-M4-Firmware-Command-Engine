#ifndef MEMORY_INFO_H
#define MEMORY_INFO_H
#define CODE_SIZE       13278
#define RO_DATA_SIZE     690
#define RW_DATA_SIZE     224
#define ZI_DATA_SIZE    2928
#define FLASH_USED (CODE_SIZE + RO_DATA_SIZE + RW_DATA_SIZE)
#define RAM_USED   (RW_DATA_SIZE + ZI_DATA_SIZE)
void cmd_code_size(void);
#endif