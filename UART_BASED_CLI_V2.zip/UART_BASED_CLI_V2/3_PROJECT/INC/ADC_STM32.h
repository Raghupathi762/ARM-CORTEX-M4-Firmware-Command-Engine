#ifndef ADC_H
#define ADC_H
void km_adc_init(void);
void start();
#endif