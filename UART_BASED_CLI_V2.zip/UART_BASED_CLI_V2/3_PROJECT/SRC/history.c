#include "main.h"
extern char RX_DATA[1000];
static uint8_t i=0,j=0;
	char arr[5][15];
void history_save(void)
{
		if(i==5)
	{
		for(i=0;i<4;i++)
		{
			strcpy(arr[i],arr[i+1]);
		}
		i=4;
	}
	memset(arr[i],'\0',10);
	strcpy(arr[i],RX_DATA);
	i++;
	}

void history_show(void)
{
	  uart_string((uint8_t *)"\r\n");
    for(j = 0; j < i; j++)
    {
        uart_string((uint8_t *)arr[j]);
        uart_string((uint8_t *)"\r\n");
    }
}
void history_clear(void)
{
	memset(arr,'\0',75);
	i=0;
	uart_string((uint8_t *)"history clear...... \r\n");
}