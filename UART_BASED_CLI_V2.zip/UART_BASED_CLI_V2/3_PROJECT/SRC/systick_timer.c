#include "stm32f401rbt6.h"
#include "systick_timer.h"

volatile unsigned int count = 0;
volatile unsigned int temp_count = 0;

/****************************** M DELAY IT *******************************************/
void KM_Delay_ms(int delay)
{

    SYSTICK->CTRL = 0x00;
    SYSTICK->LOAD = 15999;
    SYSTICK->VAL = 0x00;
    SYSTICK->CTRL = 0x07;
    temp_count = count + delay;
    while (count < temp_count);
    count = 0;
    temp_count = 0;
//	  STK_CTRL = 0x00;
}

/****************************** U DELAY IT *******************************************/
void KM_Delay_us(int delay)
{
    SYSTICK->CTRL = 0x00;
    SYSTICK->LOAD = 15;
    SYSTICK->VAL = 0x00;
    SYSTICK->CTRL = 0x07;
    temp_count = count + delay;
    while (count < temp_count);
    count = 0;
    temp_count = 0;
	  SYSTICK->CTRL = 0x00;
}
/****************************** M DELAY POLLING  *******************************************/
void KM_Mdelay(int delay)
{
    SYSTICK->CTRL = 0x00;
    SYSTICK->LOAD = (16000 * delay) - 1;
    SYSTICK->VAL = 0x00;
    SYSTICK->CTRL = 0x05;
    while (!(SYSTICK->CTRL & (1 << 16)));
 //   STK_CTRL = 0x00;
}
/****************************** U DELAY POLLING *******************************************/
void KM_udelay(int delay)
{
    SYSTICK->CTRL = 0x00;
    SYSTICK->LOAD = (16 * delay) - 1;
    SYSTICK->VAL = 0x00;
    SYSTICK->CTRL = 0x05;
    while (!(SYSTICK->CTRL & (1 << 16)));
 //   STK_CTRL = 0x00;
}

void SysTick_Handler(void)
{
    count++;
}