#include "stm32f401rbt6.h"
#include "main.h"
#define STEP_VAL 0.0008f               //STEP VALUE

volatile unsigned int LM35_ADC,POT_ADC;
volatile float pot_vol,LM35_VOL,POT_VOL;
volatile uint32_t temp;
void km_adc_init()
{
	RCC->APB2ENR  |=1<<8;                  //ADC ENABLE 
	KM_GPIO_Pin_Mode(GPIOC_PORT,0,ANL);
	ADC->SQR3 |= (0x0A);                   // SEQURNCE REGITER SET IT IS FIRST ADC CONVERSION
	ADC->SMPR1  |= 7;                      //SAMPLING TIME 
  //ADC->CR2 |=1<<1;                       //CONTINUES MODE
	ADC->CR1 |=1<<5;                       //INTERRUPT ENABLE 
  //ADC_CR2 |=1<<10;                     //EOCS ENABLE REGULARE CONVERSION 
	NVIC->ISER[0] |=1<<18;                   // ADC INTERRUTP
	ADC->CR2 |=1<<0;                       //ADC POWER ON 	
}
void start()
{
		ADC->CR2 |=1<<30;                      //START CONVERSION
}

void ADC_IRQHandler ()
{
		LM35_ADC=ADC->DR;
		LM35_VOL=LM35_ADC*STEP_VAL;
		temp=LM35_VOL*100;
}