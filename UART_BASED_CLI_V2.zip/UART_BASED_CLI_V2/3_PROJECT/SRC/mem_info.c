#include "memory.h"
#include "UART.h"
#include "main.h"

void cmd_code_size(void)
{
	char *buff=(char *)calloc(50,1);
    uart_string((uint8_t *)"\r\n========== FIRMWARE MEMORY ==========\r\n");
	  sprintf(buff,"Code           : %d Bytes\r\n",CODE_SIZE);
    uart_string((uint8_t *)buff);
	  sprintf(buff,"RO-data        : %d Bytes\r\n",RO_DATA_SIZE);
	  uart_string((uint8_t *)buff);
	  sprintf(buff,"RW-data        : %d Bytes\r\n",RW_DATA_SIZE );
		uart_string((uint8_t *)buff);
    sprintf(buff,"ZI-data        : %d Bytes\r\n",ZI_DATA_SIZE );
		uart_string((uint8_t *)buff);
	  sprintf(buff,"FLASH_USED     : %d Bytes\r\n", FLASH_USED );
		uart_string((uint8_t *)buff);
   	sprintf(buff,"RAM_USED       : %d Bytes\r\n",RAM_USED);
		uart_string((uint8_t *)buff);
    uart_string((uint8_t *)"=====================================\r\n");
	  free(buff);
}