
#include "MAIN.h"
#include "stm32f401rbt6.h"
uint8_t  rtc_data[7];
char date[20];
extern char ch,j,found;
extern uint8_t  i;
extern volatile uint32_t temp;
extern void (*SENDER)(void);
void KM_Delay_ms(int delay)	
{
		volatile int k;
		for(k=0;k<16000*delay;k++);
}

/* this are all cmds */
char *cmd[] =
{
		"help\r",
		"version\r",
		"clear\r",
		"info\r",
		"time\r",
		"date\r",
		"led_on\r",
		"led_off\r",
		"board_info\r",
		"adc_info\r",
		"gpio_info\r",
		"int_info\r",
		"temp\r",
		"code_size\r",
	  "whoami\r",
	  "wifi_info\r",
	  "wifi_status\r",
	  "reset\r",
	  "history\r",
    "history_clear\r",	
};

/* array of funtion pointer*/
void (*cmd_func[])(void) =
{
		help_cmd,
		version_cmd,
		clear_cmd,
		info_cmd,
		time_cmd,
		date_cmd,
		led_on_cmd,
		led_off_cmd,
		board_info_cmd,
		adc_info_cmd,
		gpio_info_cmd,
		interrupt_info_cmd,
		adc_temp_cmd,
		cmd_code_size,
	  whoami_cmd,
	  wifi_info_cmd,
	  wifi_status_cmd,
	  reset_cmd,
	  history_info_cmd,
	  history_clear_cmd,
};
void command_execute(char *RX_DATA)
{
	found = 0;

	for(j = 0; j < (sizeof(cmd) / sizeof(cmd[0])); j++)
	{
			if(strcmp(RX_DATA, cmd[j]) == 0)
			{
					i=0;
					found=1;
					cmd_func[j]();
				  history_save();
					memset(RX_DATA,'\0',200);
					uart_string((uint8_t *)GREEN);
					uart_string((uint8_t *)"STM32:-/myproject/uart/cmd/line$ ");
					uart_string((uint8_t *)RESETT);
					break;
			}
		}
	
	if(found == 0)
	{
			if(i > 1 && ch == '\r')
			{
				wrong_cmd();
				memset(RX_DATA, '\0', 200);
				uart_string((uint8_t *)GREEN);
				uart_string((uint8_t *)"STM32:-/myproject/uart/cmd/line$ ");
				uart_string((uint8_t *)RESETT);
					i = 0;
			}
	}
}

void help_cmd(void)
		{   
		uart_string((uint8_t *)"\r\n========================================\r\n");
		uart_string((uint8_t *)"   AVAILABLE COMMANDS LIST  \r\n");
		uart_string((uint8_t *)"========================================\r\n");
		uart_string((uint8_t *)"help       - Display available commands\r\n");
		uart_string((uint8_t *)"version    - Display firmware version\r\n");
		uart_string((uint8_t *)"clear      - Clear terminal screen\r\n");
		uart_string((uint8_t *)"info       - Display system information\r\n");	
		uart_string((uint8_t *)"time       - Display current time\r\n");
		uart_string((uint8_t *)"date       - Display current date\r\n");
		uart_string((uint8_t *)"led_on     - Turn the user LED ON\r\n");
		uart_string((uint8_t *)"led_off    - Turn the user LED OFF\r\n");
		uart_string((uint8_t *)"board_info - Display board specifications\r\n");
		uart_string((uint8_t *)"adc_info   - Display ADC configuration and specifications\r\n");
		uart_string((uint8_t *)"gpio_info  - Display GPIO configuration and specifications\r\n");
		uart_string((uint8_t *)"int_info   - Display interrupt specifications\r\n");
		uart_string((uint8_t *)"temp       - Display LM35 temperature\r\n");
		uart_string((uint8_t *)"whoami     - Display project name\r\n");
		uart_string((uint8_t *)"code_size  - Display firmware memory usage\r\n");
	  uart_string((uint8_t *)"wifi_info  - Display wifi information\r\n");
		uart_string((uint8_t *)"wifi_status   - Display wifi information\r\n");
		uart_string((uint8_t *)"reset         - STM32 CONTROLLER RESET\r\n");
		uart_string((uint8_t *)"history       - Display the  CMD History \r\n");
		}
void version_cmd(void)
{
	uart_string((uint8_t *)"\r\n========================================\r\n");
	uart_string((uint8_t*)"  'Firmware Version':- 2.2.6\r\n");
	uart_string((uint8_t *)"========================================\r\n");

}
void clear_cmd(void)
{

	uart_string((uint8_t *)"\033[2J\033[H");
	uart_string((uint8_t *)"\r\n");
	uart_string((uint8_t *)"========================================\r\n");
	uart_string((uint8_t *)"   UART-Based Command-Line Interface (CLI) \r\n");
	uart_string((uint8_t *)"========================================\r\n");
}
void info_cmd(void)
{

	uart_string((uint8_t *)"\r\nDevice Information\r\n");
	uart_string((uint8_t *)"Controller  : STM32F401RBT6\r\n");
	uart_string((uint8_t *)"Core        : ARM Cortex-M4\r\n");
	uart_string((uint8_t *)"Flash       : 128 KB\r\n");
	uart_string((uint8_t *)"SRAM        : 64 KB\r\n");
	uart_string((uint8_t *)"build date : " __DATE__ "\r\n");
	uart_string((uint8_t *)"build time : " __TIME__ "\r\n");
}

void date_cmd(void)
{
 
	KM_I2C_Mem_Read(0x68,0x04,0x01,&rtc_data[3],3);
	sprintf(date,"\r\n\"%02x-%02x-%02x\"\r\n",rtc_data[3],rtc_data[4],rtc_data[5]);
	uart_string((uint8_t *)date);

}
void time_cmd(void)
	{
		KM_I2C_Mem_Read(0x68,0x00,0x01,rtc_data,3);
		sprintf(date,"\r\n\"%02x:%02x:%02x\"\r\n",rtc_data[2],rtc_data[1],rtc_data[0]);
		uart_string((uint8_t *)date);
	}
void wrong_cmd(void)
	{
		uart_string((uint8_t *)RED);
		uart_string((uint8_t *)"\r\n [X] Error: Invalid command!\r\n");
		uart_string((uint8_t *)"Type 'help' to see available commands.\r\n");
		uart_string((uint8_t *)RESETT);
	}
void led_on_cmd(void)
	{
	KM_GPIO_Write_Pin(GPIOB_PORT,13,0);
	uart_string((uint8_t *)"\r\n\"RED LED ON\"\r\n");
	}
void led_off_cmd(void)
	{
	KM_GPIO_Write_Pin(GPIOB_PORT,13,1);
	uart_string((uint8_t *)"\r\n\"RED LED off\"\r\n");
}
void board_info_cmd(void)
{
	uart_string((uint8_t *)"\r\n================================================\r\n");
	uart_string((uint8_t *)"        development board\r\n");
	uart_string((uint8_t *)"================================================\r\n");
	uart_string((uint8_t *)"\r\n[ mcu information ]\r\n");
	uart_string((uint8_t *)"board       : raayan mini rev 4.0/4.1\r\n");
	uart_string((uint8_t *)"controller  : stm32f401rbt6\r\n");
	uart_string((uint8_t *)"core        : arm cortex-m4\r\n");
	uart_string((uint8_t *)"architecture: 32-bit\r\n");
	uart_string((uint8_t *)"fpu         : available\r\n");
	uart_string((uint8_t *)"flash       : 128 kb\r\n");
	uart_string((uint8_t *)"sram        : 64 kb\r\n");
	uart_string((uint8_t *)"max clock   : 84 mhz\r\n");
	uart_string((uint8_t *)"\r\n[ on-board peripherals ]\r\n");
	uart_string((uint8_t *)"gpio        : available\r\n");
	uart_string((uint8_t *)"user leds   : 2\r\n");
	uart_string((uint8_t *)"user buttons: 3\r\n");
	uart_string((uint8_t *)"buzzer      : available\r\n");
	uart_string((uint8_t *)"lcd         : 16x2 monochrome\r\n");
	uart_string((uint8_t *)"tft display : spi interface\r\n");
	uart_string((uint8_t *)"\r\n[ communication interfaces ]\r\n");
	uart_string((uint8_t *)"uart        : usart interfaces\r\n");
	uart_string((uint8_t *)"i2c         : available\r\n");
	uart_string((uint8_t *)"spi         : available\r\n");
	uart_string((uint8_t *)"\r\n[ on-board modules ]\r\n");
	uart_string((uint8_t *)"rtc         : ds1307 (i2c)\r\n");
	uart_string((uint8_t *)"eeprom      : at24c08 (i2c)\r\n");
	uart_string((uint8_t *)"temperature : lm35 (adc)\r\n");
	uart_string((uint8_t *)"wi-fi       : esp wi-fi module (uart)\r\n");
	uart_string((uint8_t *)"usb         : usb type-a interface\r\n");
	uart_string((uint8_t *)"\r\n[ debug interface ]\r\n");
	uart_string((uint8_t *)"debugger    : st-link\r\n");
	uart_string((uint8_t *)"programming : supported\r\n");
	uart_string((uint8_t *)"debugging   : supported\r\n");
	uart_string((uint8_t *)"\r\n================================================\r\n");
}
void  adc_info_cmd(void)
{
 uart_string((uint8_t *)"\r\n================================================\r\n");
	uart_string((uint8_t *)"                 adc information\r\n");
	uart_string((uint8_t *)"================================================\r\n");
	uart_string((uint8_t *)"\r\n[ adc specifications ]\r\n");
	uart_string((uint8_t *)"controller        : stm32f401rbt6\r\n");
	uart_string((uint8_t *)"adc peripheral    : adc1\r\n");
	uart_string((uint8_t *)"architecture      : successive approximation (sar)\r\n");
	uart_string((uint8_t *)"resolution        : 12-bit\r\n");
	uart_string((uint8_t *)"maximum value     : 4095\r\n");
	uart_string((uint8_t *)"external channels : up to 16\r\n");
	uart_string((uint8_t *)"data register     : 16-bit\r\n");
	uart_string((uint8_t *)"\r\n[ conversion modes ]\r\n");
	uart_string((uint8_t *)"single            : supported\r\n");
	uart_string((uint8_t *)"continuous        : supported\r\n");
	uart_string((uint8_t *)"scan              : supported\r\n");
	uart_string((uint8_t *)"discontinuous     : supported\r\n");
	uart_string((uint8_t *)"\r\n[ adc features ]\r\n");
	uart_string((uint8_t *)"analog watchdog   : supported\r\n");
	uart_string((uint8_t *)"interrupt         : supported\r\n");
	uart_string((uint8_t *)"dma               : supported\r\n");
	uart_string((uint8_t *)"sampling time     : programmable\r\n");
	uart_string((uint8_t *)"data alignment    : left / right\r\n");
	uart_string((uint8_t *)"external trigger  : supported\r\n");
	uart_string((uint8_t *)"================================================\r\n");
}
void gpio_info_cmd(void)
{
	uart_string((uint8_t *)"\r\n================================================\r\n");
	uart_string((uint8_t *)"                 gpio information\r\n");
	uart_string((uint8_t *)"================================================\r\n");
	uart_string((uint8_t *)"\r\n[ gpio specifications ]\r\n");
	uart_string((uint8_t *)"controller       : stm32f401rbt6\r\n");
	uart_string((uint8_t *)"gpio ports       : gpioa to gpioe\r\n");
	uart_string((uint8_t *)"architecture     : 32-bit\r\n");
	uart_string((uint8_t *)"maximum pins     : 50 gpio pins (port capacity)\r\n");
	uart_string((uint8_t *)"\r\n[ gpio modes ]\r\n");
	uart_string((uint8_t *)"input            : supported\r\n");
	uart_string((uint8_t *)"output           : supported\r\n");
	uart_string((uint8_t *)"alternate function: supported\r\n");
	uart_string((uint8_t *)"analog           : supported\r\n");
	uart_string((uint8_t *)"\r\n[ gpio features ]\r\n");
	uart_string((uint8_t *)"output type      : push-pull / open-drain\r\n");
	uart_string((uint8_t *)"pull resistors   : pull-up / pull-down\r\n");
	uart_string((uint8_t *)"speed            : low / medium / high / very high\r\n");
	uart_string((uint8_t *)"interrupt        : exti supported\r\n");
	uart_string((uint8_t *)"locking          : pin configuration lock\r\n");
	uart_string((uint8_t *)"\r\n[ gpio registers ]\r\n");
	uart_string((uint8_t *)"moder            : mode register\r\n");
	uart_string((uint8_t *)"otyper           : output type register\r\n");
	uart_string((uint8_t *)"ospeedr          : output speed register\r\n");
	uart_string((uint8_t *)"pupdr            : pull-up/pull-down register\r\n");
	uart_string((uint8_t *)"idr              : input data register\r\n");
	uart_string((uint8_t *)"odr              : output data register\r\n");
	uart_string((uint8_t *)"bsrr             : bit set/reset register\r\n");
	uart_string((uint8_t *)"afr              : alternate function register\r\n");
	uart_string((uint8_t *)"================================================\r\n");
}
void interrupt_info_cmd(void)
{
	uart_string((uint8_t *)"\r\n================================================\r\n");
	uart_string((uint8_t *)"              interrupt information\r\n");
	uart_string((uint8_t *)"================================================\r\n");
	uart_string((uint8_t *)"\r\n[ interrupt controller ]\r\n");
	uart_string((uint8_t *)"controller       : cortex-m4 nvic\r\n");
	uart_string((uint8_t *)"peripheral irqs  : 52 maskable channels\r\n");
	uart_string((uint8_t *)"core exceptions  : 16 exception inputs\r\n");
	uart_string((uint8_t *)"priority bits    : 4\r\n");
	uart_string((uint8_t *)"priority levels  : 16\r\n");
	uart_string((uint8_t *)"\r\n[ external interrupts ]\r\n");
	uart_string((uint8_t *)"gpio exti lines  : 16 (exti0 - exti15)\r\n");
	uart_string((uint8_t *)"internal exti    : 7 lines\r\n");
	uart_string((uint8_t *)"trigger modes    : rising / falling / both\r\n");
	uart_string((uint8_t *)"software trigger : supported\r\n");
	uart_string((uint8_t *)"\r\n[ interrupt features ]\r\n");
	uart_string((uint8_t *)"nested interrupts: supported\r\n");
	uart_string((uint8_t *)"enable / disable: supported\r\n");
	uart_string((uint8_t *)"pending status   : supported\r\n");
	uart_string((uint8_t *)"\r\n[ important registers ]\r\n");
	uart_string((uint8_t *)"nvic_iser        : interrupt set enable\r\n");
	uart_string((uint8_t *)"nvic_icer        : interrupt clear enable\r\n");
	uart_string((uint8_t *)"nvic_ispr        : interrupt set pending\r\n");
	uart_string((uint8_t *)"nvic_icpr        : interrupt clear pending\r\n");
	uart_string((uint8_t *)"nvic_ipr         : interrupt priority\r\n");
	uart_string((uint8_t *)"exti_imr         : interrupt mask\r\n");
	uart_string((uint8_t *)"exti_rtsr        : rising trigger selection\r\n");
	uart_string((uint8_t *)"exti_ftsr        : falling trigger selection\r\n");
	uart_string((uint8_t *)"exti_pr          : pending register\r\n");
	uart_string((uint8_t *)"================================================\r\n");
}
void adc_temp_cmd(void)
{
	char buff[30];
	start();//software start
	sprintf(buff,"\r\n\"TEMPERTURE %d C\"\r\n",temp); 
	uart_string((uint8_t *)buff);
}
void whoami_cmd(void)
{  
	  uart_string((uint8_t *)BOLD);
    uart_string((uint8_t *)" \r\nUART-Based Command-Line Interface (CLI) \r\n");
		uart_string((uint8_t *)RESETT);
}
void wifi_info_cmd(void)
{
    uart_string((uint8_t *)"\r\n[ module details ]\r\n");
    uart_string((uint8_t *)"module       : esp8266\r\n");
    uart_string((uint8_t *)"technology   : 2.4 ghz wi-fi\r\n");
    uart_string((uint8_t *)"protocol     : ieee 802.11 b/g/n\r\n");
    uart_string((uint8_t *)"interface    : uart using at commands\r\n");
}
void wifi_status_cmd(void)
{
	uart_string((uint8_t *)"\r\nWiFi connecting Checking..........\r\n");
	SENDER=AT;
	SENDER();//CALLING AT CMD FUNTION
	SENDER();//CALLING AT RST
	SENDER();//CALLING CMODE
	SENDER();//calling cjap
	if(SENDER==NULL)
	uart_string((uint8_t *)"WiFi connected \r\n");
	else
	uart_string((uint8_t *)"WiFi not connectded \r\n");
}
void reset_cmd(void)
{
		uint8_t j=0;
		uart_string((uint8_t *)RED);
		uart_string((uint8_t *)"\r\nsystem resetting");
		for(j = 0; j < 20; j++)
		{
				uart2_tx('.');
				KM_Delay_ms(10);
		} 
    uart_string((uint8_t *)"\r\nrestart initiated...\r\n");
    KM_Delay_ms(100);
    SCB_AIRCR = (0x5FA << 16) | (1 << 2);
    while(1);
}
void history_info_cmd(void)
{
	history_show();
}
void history_clear_cmd(void)
{
	history_clear();
}