#include "stm32f401rbt6.h"
#include "main.h"
void KM_GPIO_Init(unsigned int port )
{
	 RCC->AHB1ENR |=1<<port;
}
void KM_GPIO_Pin_Mode(unsigned int port,unsigned int pin,unsigned int mode )
{
	switch(port)
	{
		case GPIOA_PORT:switch(mode)
		           {
			          case OUT:GPIOA->MODER &=~(0X03U<<pin*2);
									       GPIOA->MODER |=(0X01U<<pin*2);
								          break;
								case IN:GPIOA->MODER &=~(0X03U<<pin*2);
								          break;
								case ALT :GPIOA->MODER &=~(0X03U<<pin*2);
									       GPIOA->MODER |=(0X02U<<pin*2);
								           break;
								 case ANL :GPIOA->MODER &=~(0X03U<<pin*2);
									       GPIOA->MODER |=(0X03U<<pin*2);
								           break;
								case PULL_UP:GPIOA->PUPDR &=~(0x03U<<pin*2);
								           GPIOA->PUPDR |=(0x01U<<pin*2);
								           break;
								 case PULL_DOWN:GPIOA->PUPDR &=~(0x03U<<pin*2);
								           GPIOA->PUPDR |=(0x02U<<pin*2);
								           break;
							 }
							 break;
		 case GPIOB_PORT:switch(mode)
		           {
			          case OUT:GPIOB->MODER &=~(0X03U<<pin*2);
									       GPIOB->MODER |=(0X01U<<pin*2);
								          break;
								case IN:GPIOB->MODER &=~(0X03U<<pin*2);
								          break;
								case ALT :GPIOB->MODER &=~(0X03U<<pin*2);
									       GPIOB->MODER |=(0X02<<pin*2);
								           break;
								 case ANL :GPIOB->MODER &=~(0X03U<<pin*2);
									       GPIOB->MODER |=(0X03<<pin*2);
								           break;
								case PULL_UP:GPIOB->PUPDR &=~(0x03U<<pin*2);
								           GPIOB->PUPDR |=(0x01U<<pin*2);
								           break;
								 case PULL_DOWN:GPIOB->PUPDR &=~(0x03U<<pin*2);
								           GPIOB->PUPDR |=(0x02U<<pin*2);
								           break;
								 
							 }
							 break;
		case GPIOC_PORT:switch(mode)
		           {
			          case OUT:GPIOC->MODER &=~(0X03U<<pin*2);
									       GPIOC->MODER |=(0X01U<<pin*2);
								          break;
								case IN:GPIOC->MODER &=~(0X03U<<pin*2);
								          break;
								case ALT :GPIOC->MODER &=~(0X03U<<pin*2);
									       GPIOC->MODER |=(0X02U<<pin*2);
								           break;
								 case ANL :GPIOC->MODER &=~(0X03U<<pin*2);
									       GPIOC->MODER |=(0X03U<<pin*2);
								           break;
								case PULL_UP:GPIOC->PUPDR &=~(0x03U<<pin*2);
								           GPIOC->PUPDR |=(0x01<<pin*2);
								           break;
								 case PULL_DOWN:GPIOC->PUPDR &=~(0x03U<<pin*2);
								           GPIOC->PUPDR |=(0x02U<<pin*2);
								           break;	 
							 }
								 
	}	
}
void KM_GPIO_Write_Pin(unsigned int port,unsigned int pin,unsigned int data)
{
switch(port)
	{
	case GPIOA_PORT:switch(data)
          	{
	         	case RESET: GPIOA->ODR &=~(1U<<pin);
	        	break;
	        	case SET: GPIOA->ODR |=(1U<<pin);
		        break;		
	          }
						break;
case GPIOB_PORT:switch(data)
          	{
	         	case RESET: GPIOB->ODR &=~(1U<<pin);
	        	break;
	        	case SET: GPIOB->ODR |=(1U<<pin);
		        break;		
	          }
						break;
case GPIOC_PORT:switch(data)
          	{
	         	case RESET: GPIOC->ODR &=~(1U<<pin);
	        	break;
	        	case SET: GPIOC->ODR |=(1U<<pin);
		        break;		
	          }
						break;						
            }
	}
void KM_GPIO_Toggle(unsigned int port ,unsigned int  pin)
{
	switch(port)
	{
case GPIOA_PORT: GPIOA->ODR ^=(1U<<pin);
	        	break;
case GPIOB_PORT: GPIOB->ODR ^=(1U<<pin);
	        	break;
case GPIOC_PORT: GPIOC->ODR ^=(1U<<pin);
	        	break;
}
}

int KM_GPIO_Read_Pin(unsigned int port ,unsigned int  pin)
{
	switch(port)
	{
		case GPIOA_PORT: return (GPIOA->IDR&(1U<<pin));
		case GPIOB_PORT: return (GPIOB->IDR&(1U<<pin));
		case GPIOC_PORT: return (GPIOC->IDR&(1U<<pin));
	}
	return 0;
}
