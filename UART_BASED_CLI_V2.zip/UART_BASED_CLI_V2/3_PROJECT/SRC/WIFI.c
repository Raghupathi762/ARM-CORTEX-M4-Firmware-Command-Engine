#include "stm32f401rbt6.h"
#include "main.h"
static int temp=40;
char x[1000];

static unsigned int z=0;
static unsigned int i=0;
char data;
void (*SENDER)(void);

void delay(uint16_t n)
{
	volatile uint32_t i=0;
	for(i=0;i<1600*n;i++);
}

/*****************************************************OUT CHAR  FUNCTION **************************************/
void UART_OUT_Char_red(char data)
{
	while(!(UART6->SR&(1<<7)));
	UART6->DR=data;
}
	/*****************************************************WRITE CMD FUNCTION**************************************/
void UART_OUT_WRITE_CMD(char str[])
{
	  z=0;
		while(str[z]!='\0')
		{
	    UART_OUT_Char_red(str[z]);
			z++;
		}
}

char USART6_Rx(uint16_t n)
{
    while(n)
    {
        if(UART6->SR & (1 << 5))
        {
            x[i] = UART6->DR;
            i++;
        }
				n--;
    }

    x[i] = '\0';

    return 1;
}
/*****************************************************MAIN**************************************/
void  Km_wifi_init()
{
	RCC->AHB1ENR |=1U<<2;						// ENABEL CLOCK PORT C
	RCC->APB2ENR  |=1U<<5;						//ENABLE CLOCK FOR UART_6
	GPIOC->MODER |=2<<12;						//ENABLE ALTERNATE MODE C PC6
	GPIOC->MODER |=2<<14;            //ENABLE ALTERNATE MODE C PC7
	GPIOC->AFRL  |=((8<<24)|(8<<28));//UART  CHANNEL ENBALE 
	UART6->BRR |=0x8A;							//BAUD RATE ENABEL
  NVIC->ISER[2]|=1<<7;							//INTERRUPT ENABLE
	UART6->CR1 |=1<<13;							//UART ENABLE 
  UART6->CR1 |=1<<5;							//RXNE INTERRUPT ENABLE 
	UART6->CR1 |=3<<2;							//TX AND RX ENABLE
}
			/************************AT CMD*****************************************/
void AT(void)
	{
      memset(x,'\0',1000);
	    i=0;
		  UART_OUT_WRITE_CMD("AT\r\n");
	    delay(1000);
   if(strstr(x,"OK"))
		{
			SENDER=AT_RST;
			i=0;
		}
	}
		/************************AT+RST*****************************************/
void  AT_RST(void)
{
	 memset(x,'\0',1000);
	    i=0;
		UART_OUT_WRITE_CMD("AT+RST\r\n");
	  delay(1000);
		if(strstr(x,"OK"))
		{
		SENDER=AT_CWMODE;
		}
		if(strstr(x,"WIFI CONNECTED"))
			SENDER=AT_MUX;
}

		/************************AT+CWMODE*****************************************/
void AT_CWMODE(void)
{
	 memset(x,'\0',1000);
	    i=0;
		UART_OUT_WRITE_CMD("AT+CWMODE=3\r\n");
	    delay(1000);
		if(strstr(x,"OK"))
		{
			SENDER=AT_CWJAP;
		}
}
			/************************AT+CWJAP*****************************************/
void AT_CWJAP(void)
{
			 memset(x,'\0',1000);
	    i=0;

			UART_OUT_WRITE_CMD("AT+CWJAP=\"SSID\",\"PASSWORD\"\r\n");//ENTER YOUR SSID AND PASSWORD  
      delay(1000);	
			if(strstr(x,"WIFI CONNECTED"))
			{
					//SENDER=AT_MUX;
					SENDER=NULL;
			}
	}
			/******************************MUX***********************************/
	void AT_MUX(void)
	{
		   memset(x,'\0',1000);
	    i=0;
			UART_OUT_WRITE_CMD("AT+MUX=0\r\n");    
      delay(1000);	
			if(strstr(x,"OK"))
			{
			SENDER=AT_CIPSTATUS;
			}
	}
		/******************************STATUS***********************************/
	void AT_CIPSTATUS(void)
	{
		memset(x,'\0',1000);
		UART_OUT_WRITE_CMD("AT+CIPSTATUS\r\n");   
	  delay(1000);
		if(strstr(x,"OK"))
		{
			SENDER=AT_CIPSTART;
		}
	}
		/******************************START***********************************/
void AT_CIPSTART(void)
{
	  memset(x,'\0',1000);
		UART_OUT_WRITE_CMD("AT+CIPSTART=\"TCP\",\"142.93.218.33\",80\r\n"); 
      delay(1000);
		if(strstr(x,"CONNECT"))
		{
			SENDER=AT_CIPSEND;
		}
}

	/******************************SEND***********************************/
void AT_CIPSEND(void)
{
		memset(x,'\0',1000);
		UART_OUT_WRITE_CMD("AT+CIPSEND=37\r\n");  
   delay(1000);
		if(strstr(x,"OK"))
		{
			SENDER=AT_POST;
		}
}
/**********************GET************************************/
void AT_POST(void)
{
//	memset(x,'\0',1000);
//		sprintf(post,"GET /page.php?temp=%d&hum=40&dev=42\r\n",temp);
//	  delay(1000);
//		UART_OUT_WRITE_CMD(post);   
//		if(strstr(x,"hellodone"))
//		{
//			SENDER=AT_CIPSTATUS;
//			sprintf(strr,"temp=%d",temp);
//		}
}

void USART6_IRQHandler()
{
	if(UART6->SR&(1<<5))
	{
	x[i++]=UART6->DR;
	x[i] = '\0';
 }
}

