	#include "stm32f401rbt6.h"
	#include "UART.h"
	uint8_t  RX_DATA[200];
	uint8_t  i=0;
	char flag=0;
void uart2_tx(uint8_t data)
  {
	while(!(UART2->SR&(1<<7)));
	UART2->DR=data&0xff;
  }

int uart2_rx(void)
	{
		while(!(UART2->SR&(1<<5)));
		RX_DATA[0]=UART2->DR;
		return RX_DATA[0];
  }

void uart_string(uint8_t str[])
  {
	uint8_t j=0;
    while(str[j]!='\0')
	{
	uart2_tx(str[j++]);
	}
  }
  
void Uart2_Init()
	{
		RCC->APB1ENR |=1U<<17;
		RCC->AHB1ENR |=1U<<0;
		GPIOA->MODER &=~(0xFU<<2);
		GPIOA->MODER |=0xAU<<4;
		GPIOA->AFRL  |=0x77U<<8;
		UART2->BRR    =0X683;
		UART2->CR1   |=1U<<5;//INTERUPT ENABLE
		UART2->CR1   |=3U<<2;//RX-TX ENALBE
		NVIC->ISER[1]  |=1U<<6; //INTERUPT ENABEL	
		UART2->CR1   |=1U<<13;//UART ENABLE 
	}
	void USART2_IRQHandler()
	{
	if(UART2->SR&(1<<5))
	{
	RX_DATA[i++]=UART2->DR;
	RX_DATA[i] = '\0';
	if(RX_DATA[i-1]==0x03)
	{
		  flag |= (1 << 1);
	}
	flag |=1<<0;//seting flag bit 	
	}

	}

