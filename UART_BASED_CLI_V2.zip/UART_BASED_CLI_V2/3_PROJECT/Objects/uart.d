.\objects\uart.o: SRC\UART.c
.\objects\uart.o: ..\..\MULTIPLE_FILES\INC\stm32f401rbt6.h
.\objects\uart.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\uart.o: .\INC\UART.h
